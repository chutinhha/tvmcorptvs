﻿Add-PsSnapin Microsoft.SharePoint.PowerShell
Enable-SPSessionStateService –DefaultProvision
Remove-PsSnapin Microsoft.SharePoint.PowerShell